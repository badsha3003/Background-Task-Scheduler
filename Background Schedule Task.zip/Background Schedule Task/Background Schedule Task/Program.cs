using Background_Schedule_Task.Controllers;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

builder.Services.AddSwaggerGen();

builder.Services.AddRazorPages();
builder.Services.AddControllers();
builder.Services.AddSingleton<TaskScheduerServices>();
builder.Services.AddHostedService(provider => provider.GetRequiredService<TaskScheduerServices>());
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddCors(
     opt => {
         opt.AddDefaultPolicy(
              pol => {
                  pol.AllowAnyOrigin();
                  pol.AllowAnyMethod();
                  pol.AllowAnyHeader();
              }
             );
     }
    );

var app = builder.Build();

if (!app.Environment.IsProduction())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();
app.MapControllers();

app.MapRazorPages();

app.Run();
