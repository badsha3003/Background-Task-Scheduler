﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Background_Schedule_Task.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly TaskScheduerServices _taskScheduler;

        public TaskController(TaskScheduerServices taskScheduler)
        {
            _taskScheduler = taskScheduler;
        }

        [HttpPost("Add Task")]
        public IActionResult AddTask(string taskId, int intervalInSeconds)
        {
            _taskScheduler.AddOrUpdateTask(taskId, async cancellationToken =>
            {
                
                await Task.Delay(1000, cancellationToken);
            }, TimeSpan.FromSeconds(intervalInSeconds));

            return Ok($"Task {taskId} added/updated.");
        }

        [HttpDelete("Delete task")]
        public IActionResult RemoveTask(string taskId)
        {
            _taskScheduler.RemoveTask(taskId);
            return Ok($"Task {taskId} removed.");
        }

        [HttpPost("PauseTask")]
        public IActionResult PauseTask(string taskId)
        {
            _taskScheduler.PauseTask(taskId);
            return Ok($"Task {taskId} paused.");
        }

        [HttpPost("ResumeTask")]
        public IActionResult ResumeTask(string taskId)
        {
            _taskScheduler.PauseTask(taskId);
            return Ok($"Task {taskId} resumed.");
        }
        [HttpPut("UpdateTask")]
        public IActionResult UpdateTask(string taskId, int newIntervalInSeconds)
        {
            _taskScheduler.AddOrUpdateTask(taskId, async cancellationToken =>
            {
               
                await Task.Delay(1000, cancellationToken);
            }, TimeSpan.FromSeconds(newIntervalInSeconds));

            return Ok($"Task {taskId} updated with new interval: {newIntervalInSeconds} seconds.");
        }
    }
}

