﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Background_Schedule_Task.Controllers
{
    [Table("ScheduleTbl")]
    public class ScheduleTask
    {
        [Key]
        public string TaskId { get; set; }
        public Func<CancellationToken, Task> Action { get; set; }
        public TimeSpan Interval { get; set; }
        public DateTime LastRunTime { get; set; }
        public bool IsPaused { get; set; }
    }
}
