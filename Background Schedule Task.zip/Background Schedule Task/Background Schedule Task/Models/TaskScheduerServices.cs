﻿using System.Collections.Concurrent;

namespace Background_Schedule_Task.Controllers
{
    public class TaskScheduerServices : BackgroundService
    {
        private readonly ConcurrentDictionary<string, ScheduleTask> _tasks = new();
        private readonly ILogger<TaskScheduerServices> _logger;

        public TaskScheduerServices(ILogger<TaskScheduerServices> logger)
        {
            _logger = logger;
        }

        public void AddOrUpdateTask(string taskId, Func<CancellationToken, Task> action, TimeSpan interval)
        {
            var task = new ScheduleTask
            {
                TaskId = taskId,
                Action = action,
                Interval = interval,
                LastRunTime = DateTime.MinValue,
                IsPaused = false
            };

            _tasks.AddOrUpdate(taskId, task, (_, _) => task);
        }

        public void RemoveTask(string taskId)
        {
            _tasks.TryRemove(taskId, out _);
        }

        public void PauseTask(string taskId)
        {
            if (_tasks.TryGetValue(taskId, out var task))
            {
                task.IsPaused = true;
            }
        }

        public void ResumeTask(string taskId)
        {
            if (_tasks.TryGetValue(taskId, out var task))
            {
                task.IsPaused = false;
            }
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Task Scheduler Service is running.");

            while (!stoppingToken.IsCancellationRequested)
            {
                foreach (var task in _tasks.Values)
                {
                    if (!task.IsPaused && DateTime.UtcNow - task.LastRunTime >= task.Interval)
                    {
                        try
                        {
                            _logger.LogInformation($"Executing task {task.TaskId}...");
                            await task.Action(stoppingToken);
                            task.LastRunTime = DateTime.UtcNow;
                            _logger.LogInformation($"Task {task.TaskId} completed.");
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, $"Error executing task {task.TaskId}");
                        }
                    }
                }

                await Task.Delay(1000, stoppingToken); 
            }

            _logger.LogInformation("Task Scheduler Service is stopping.");
        }

        private async Task RunTask(Func<CancellationToken, Task> taskAction, TimeSpan interval, CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                await taskAction(token);
                await Task.Delay(interval, token);
            }
        }
    }
}
